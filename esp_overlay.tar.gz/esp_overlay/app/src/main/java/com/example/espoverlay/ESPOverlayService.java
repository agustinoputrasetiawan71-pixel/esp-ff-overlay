package com.example.espoverlay;

import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.net.LocalSocket;
import android.net.LocalSocketAddress;
import android.os.IBinder;
import android.view.Gravity;
import android.view.WindowManager;
import java.io.DataInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ESPOverlayService extends Service {
    private WindowManager windowManager;
    private ESPView espView;
    private Thread socketThread;
    private volatile boolean running = true;

    @Override
    public void onCreate() {
        super.onCreate();

        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        espView = new ESPView(this);

        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                        WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE |
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.TOP | Gravity.START;
        windowManager.addView(espView, params);

        startSocketThread();
    }

    private void startSocketThread() {
        socketThread = new Thread(() -> {
            while (running) {
                try {
                    LocalSocket socket = new LocalSocket();
                    socket.connect(new LocalSocketAddress("/data/local/tmp/esp_socket",
                            LocalSocketAddress.Namespace.FILESYSTEM));
                    DataInputStream dis = new DataInputStream(socket.getInputStream());

                    while (running) {
                        int count = dis.readInt();
                        List<PlayerData> players = new ArrayList<>();
                        for (int i = 0; i < count; i++) {
                            float x1 = dis.readFloat();
                            float y1 = dis.readFloat();
                            float x2 = dis.readFloat();
                            float y2 = dis.readFloat();
                            int team = dis.readInt();
                            float health = dis.readFloat();
                            float distance = dis.readFloat();
                            players.add(new PlayerData(x1, y1, x2, y2, team, health, distance));
                        }
                        espView.setPlayers(players);
                    }
                } catch (IOException e) {
                    try { Thread.sleep(1000); } catch (InterruptedException ignored) {}
                }
            }
        });
        socketThread.start();
    }

    @Override
    public void onDestroy() {
        running = false;
        if (socketThread != null) socketThread.interrupt();
        if (espView != null) windowManager.removeView(espView);
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
